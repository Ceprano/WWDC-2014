/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  Game view declaration.
  
 */

#import <SceneKit/SceneKit.h>

#import "AAPLGameViewController.h"

@interface AAPLGameView : SCNView

@end
