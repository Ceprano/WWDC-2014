//
//  main.m
//  SceneKitReel-OSX
//
//  Created by Thomas Goossens on 27/04/14.
//  Copyright (c) 2014 apple. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
