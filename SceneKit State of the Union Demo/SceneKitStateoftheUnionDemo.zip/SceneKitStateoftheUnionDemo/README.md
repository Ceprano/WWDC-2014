# SceneKit State of the Union demo

This sample shows how the demo for the state the of union was realised. It includes examples of physics simulation, particles, collisions, physics field, 3D text, the integration with SpriteKit and custom GLSL shaders.

## Requirements

### Build

iOS 8 / OSX 10.10

### Runtime

iOS 8 / OSX 10.10

Copyright (C) 2014 Apple Inc. All rights reserved.
