# MetalDeferredLighting

This sample demonstrates a deferred lighting algorithm using Metal.

## Requirements

### Build

iOS 8 SDK

### Runtime

iOS 8 with an A7 device

Copyright (C) 2014 Apple Inc. All rights reserved.
