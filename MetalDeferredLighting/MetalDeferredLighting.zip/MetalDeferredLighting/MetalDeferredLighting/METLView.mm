/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
  View for Deferred lighting Metal Sample Code. Manages  framebuffers and expects a delegate to repond to render commands to perform drawing. Can be configured with 4 color attachments, depth and stencil attachments.
  
 */

#import "METLView.h"

@implementation METLView
{
@private
    __weak CAMetalLayer *_metalLayer;
    
    BOOL _layerSizeDidUpdate;
    
    id <MTLTexture>  _depthTex;
    id <MTLTexture>  _stencilTex;
    id <MTLTexture>  _colorTextures[3]; // these are for textures 1-3 (as needed), texture 0 is owned by the drawable
}

@synthesize currentDrawable    = _currentDrawable;
@synthesize currentFramebuffer = _currentFramebuffer;

+ (Class) layerClass
{
    return [CAMetalLayer class];
}

- (void) _initCommon
{
    self.opaque          = YES;
    self.backgroundColor = nil;
    
    // setting this to yes will allow Main thread to display framebuffer when
    // view:setNeedDisplay: is called by main thread
    _metalLayer = (CAMetalLayer *)self.layer;
    
    self.contentScaleFactor = [UIScreen mainScreen].scale;
    
    _metalLayer.presentsWithTransaction = NO;
    _metalLayer.drawsAsynchronously     = YES;
    
    _device = MTLCreateSystemDefaultDevice();
    
    _metalLayer.device          = _device;
    _metalLayer.pixelFormat     = MTLPixelFormatBGRA8Unorm;
    _metalLayer.framebufferOnly = YES;
    
    [self _updateDrawableSize];
}

- (id) initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
	if(self)
    {
        [self _initCommon];
    }
    
    return self;
}

- (instancetype) initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    
    if(self)
    {
        [self _initCommon];
    }
    return self;
}

- (void) releaseTextures
{
    _depthTex   = nil;
    _stencilTex = nil;
    
    for (int i = 0; i < 3; i++)
        _colorTextures[i] = nil;
}


- (MTLAttachmentDescriptor *)attachmentDescriptorWithFormat: (MTLPixelFormat) pixelFormat
                                                 clearValue: (MTLClearValue) clearValue
                                                 loadAction: (MTLLoadAction) loadAction
                                                storeAction: (MTLStoreAction) storeAction
                                                    texture: (id <MTLTexture>) texture
                                            attachmentIndex: (NSUInteger) attachmentIndex
{
    MTLAttachmentDescriptor *attachment = [MTLAttachmentDescriptor attachmentDescriptorWithTexture: texture];
    
    [attachment setLoadAction:loadAction];
    [attachment setClearValue:clearValue];
    [attachment setStoreAction: storeAction];

    return attachment;
}

- (id <MTLFramebuffer>) createFramebufferWithTexture: (id <MTLTexture>) texture
{
    MTLAttachmentDescriptor *colorAttachment0 = [self attachmentDescriptorWithFormat:colorAttachmentFormat[0]
                                                                          clearValue:colorAttachmentClearValue[0]
                                                                          loadAction:MTLLoadActionClear
                                                                         storeAction:MTLStoreActionStore
                                                                             texture:texture
                                                                     attachmentIndex:0];
    MTLFramebufferDescriptor *framebufferDescriptor = [MTLFramebufferDescriptor framebufferDescriptorWithColorAttachment: colorAttachment0];

    if (colorAttachmentFormat[1] != MTLPixelFormatInvalid)
    {
        MTLAttachmentDescriptor *colorAttachment1 = [self attachmentDescriptorWithFormat:colorAttachmentFormat[1]
                                                                              clearValue:colorAttachmentClearValue[1]
                                                                              loadAction:MTLLoadActionClear
                                                                             storeAction:MTLStoreActionDontCare
                                                                                 texture:_colorTextures[0]
                                                                         attachmentIndex:1];
        [framebufferDescriptor setAttachment:colorAttachment1 atIndex:MTLFramebufferAttachmentIndexColor1];
    }

    if (colorAttachmentFormat[1] != MTLPixelFormatInvalid)
    {
        MTLAttachmentDescriptor *colorAttachment2 = [self attachmentDescriptorWithFormat:colorAttachmentFormat[2]
                                                                              clearValue:colorAttachmentClearValue[2]
                                                                              loadAction:MTLLoadActionClear
                                                                             storeAction:MTLStoreActionDontCare
                                                                                 texture:_colorTextures[1]
                                                                         attachmentIndex:2];
        [framebufferDescriptor setAttachment:colorAttachment2 atIndex:MTLFramebufferAttachmentIndexColor2];
    }
    
    if (colorAttachmentFormat[1] != MTLPixelFormatInvalid)
    {
        MTLAttachmentDescriptor *colorAttachment3 = [self attachmentDescriptorWithFormat:colorAttachmentFormat[3]
                                                                              clearValue:colorAttachmentClearValue[3]
                                                                              loadAction:MTLLoadActionClear
                                                                             storeAction:MTLStoreActionDontCare
                                                                                 texture:_colorTextures[2]
                                                                         attachmentIndex:3];
        [framebufferDescriptor setAttachment:colorAttachment3 atIndex:MTLFramebufferAttachmentIndexColor3];
    }
    
    if(depthPixelFormat != MTLPixelFormatInvalid)
    {
        BOOL doUpdate = ( _depthTex.width != texture.width  ) ||  ( _depthTex.height != texture.height );
        if(!_depthTex || doUpdate)
        {
            //  If we need a depth texture and don't have one, or if the depth texture we have is the wrong size
            //  Then allocate one of the proper size
            MTLTextureDescriptor* desc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat: depthPixelFormat
                                                                                            width: texture.width
                                                                                           height: texture.height
                                                                                        mipmapped: NO];
            desc.textureType = MTLTextureType2D;
            _depthTex = [_device newTextureWithDescriptor: desc];
        }
        
        MTLAttachmentDescriptor* depthAttachment = [MTLAttachmentDescriptor attachmentDescriptorWithTexture: _depthTex];
        
        [depthAttachment setLoadAction:MTLLoadActionClear];
        [depthAttachment setClearValue:depthAttachmentClearValue];
        [depthAttachment setStoreAction: MTLStoreActionDontCare];
        
        [framebufferDescriptor setAttachment: depthAttachment
                                     atIndex: MTLFramebufferAttachmentIndexDepth];
    }
    
    if(stencilPixelFormat != MTLPixelFormatInvalid)
    {
        BOOL doUpdate  =  ( _stencilTex.width != texture.width  ) || ( _stencilTex.height != texture.height );
        if(!_stencilTex || doUpdate)
        {
            //  If we need a stencil texture and don't have one, or if the depth texture we have is the wrong size
            //  Then allocate one of the proper size
            
            MTLTextureDescriptor* desc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat: stencilPixelFormat
                                                                                            width: texture.width
                                                                                           height: texture.height
                                                                                        mipmapped: NO];
            
            desc.textureType =  MTLTextureType2D;
            _stencilTex = [_device newTextureWithDescriptor: desc];
        }
        
        MTLAttachmentDescriptor* stencilAttachment = [MTLAttachmentDescriptor attachmentDescriptorWithTexture: _stencilTex];
        
        [stencilAttachment setLoadAction:MTLLoadActionClear];
        [stencilAttachment setClearValue:stencilAttachmentClearValue];
        [stencilAttachment setStoreAction: MTLStoreActionDontCare];
        
        [framebufferDescriptor setAttachment: stencilAttachment
                                     atIndex: MTLFramebufferAttachmentIndexStencil];
    }
    
    return [_device newFramebufferWithDescriptor:framebufferDescriptor];
}

- (id <MTLFramebuffer>) currentFramebuffer
{
    if(!_currentFramebuffer)
    {
        id <CAMetalDrawable> drawable = self.currentDrawable;
        
        if(drawable)
        {
            _currentFramebuffer = [self createFramebufferWithTexture:drawable.texture];
        }
    }
    
    return _currentFramebuffer;
}


- (id <CAMetalDrawable>) currentDrawable
{
    while (_currentDrawable == nil)
    {
        _currentDrawable = [_metalLayer newDrawable];
        
        if(!_currentDrawable)
        {
            NSLog(@"CurrentDrawable is nil");
        }
    }
    
    return _currentDrawable;
}

- (void) _updateDrawableSize
{
    _drawableSize = self.bounds.size;
    
    _drawableSize.width  *= self.contentScaleFactor;
    _drawableSize.height *= self.contentScaleFactor;
    
    for (int i = 0; i < 3; i++)
    {
        // color format 0 is only used by the drawable so we skip it here
        if (colorAttachmentFormat[i+1] != MTLPixelFormatInvalid)
        {
            MTLTextureDescriptor* desc = [MTLTextureDescriptor texture2DDescriptorWithPixelFormat: colorAttachmentFormat[i+1]
                                                                                            width: _drawableSize.width
                                                                                           height: _drawableSize.height
                                                                                        mipmapped: NO];
            _colorTextures[i] = [_device newTextureWithDescriptor: desc];
        }
    }
}

- (void) display
{
    // Create autorelease pool per frame to avoid possible deadlock situations
    // because there are 3 CAMetalDrawables sitting in an autorelease pool.
    @autoreleasepool
    {
        if(_layerSizeDidUpdate)
        {
            [self _updateDrawableSize];
            
            _metalLayer.drawableSize = _drawableSize;
            
            [_delegate reshape:self];
            
            _layerSizeDidUpdate = NO;
        }
        
        // draw
        [self.delegate render:self];
        
        _currentFramebuffer = nil;
        _currentDrawable    = nil;
    }
}

- (void) setContentScaleFactor:(CGFloat)contentScaleFactor
{
    [super setContentScaleFactor:contentScaleFactor];
    
    _layerSizeDidUpdate = YES;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    _layerSizeDidUpdate = YES;
}

@end
