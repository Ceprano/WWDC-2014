/*
 Copyright (C) 2014 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 
         This is the main renderer for this sample. Acts as the update and render delegate for the view controller and performs rendering. renders in 2 passes, 1) shadow pass, 2) Gbuffer pass which retains the drawable and presents it to the screen while discard the remaining attachments
      
 */

#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>

#import "METLView.h"
#import "METLViewController.h"

#include "METLObjModel.h"
#include "METLTransforms.h"

@interface METLRenderer : NSObject <METLViewControllerDelegate, METLViewDelegate>

// renderer will create a default device at init time.
@property (nonatomic, readonly) id <MTLDevice> device;

// load all assets and configure the view before triggering rendering
- (void)configure:(METLView *)view;

@end
